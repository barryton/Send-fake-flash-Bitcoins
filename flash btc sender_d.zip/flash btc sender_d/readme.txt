<!!--------READ ME FILE-----------!!>

1, Open the send.html file.
2, Enter a valid Bitcoin Address.
3, Enter the Bitcoin Amount.
4, Select Main Network or Test Network.
5, Click on the send fake bitoin button to send a flash/fake bitoin transaction.



NOTE TO START SENDING FAKE/FLASH BITCOIN TRANSACTION YOU MUST FIRST UNLOCK YOUR ACCOUNT TO GET A VALID AUTHENTICATION KEY..!!